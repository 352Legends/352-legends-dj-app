import React, { useEffect, useRef, useState } from 'react'
import { completeAuthIfPresent, getAuth, loadSDK, startAuth, transferToDevice, playContext, pause, nextTrack, prevTrack } from '../lib/spotify'
import { Music, Play, Pause, SkipBack, SkipForward, Link as LinkIcon } from 'lucide-react'
import { attachLocalAudio } from '../lib/audio'

export default function NowPlaying(){
  const [auth, setAuth] = useState<any>(getAuth())
  const [deviceId, setDeviceId] = useState<string>('')
  const [connected, setConnected] = useState(false)
  const [playlist, setPlaylist] = useState<string>(localStorage.getItem('league_playlist_uri') || '')
  const [playerReady, setPlayerReady] = useState(false)
  const [track, setTrack] = useState<any>(null)
  const [pos, setPos] = useState(0)
  const [dur, setDur] = useState(0)
  const [seeking, setSeeking] = useState(false)
  const sliderRef = React.useRef<HTMLInputElement>(null)
  const [track, setTrack] = useState<any>(null)
  const [pos, setPos] = useState(0)

  useEffect(()=>{ completeAuthIfPresent().then(setAuth) }, [])

  useEffect(()=>{
    if (!auth) return
    // Initialize Web Playback SDK
    (window as any).onSpotifyWebPlaybackSDKReady = async () => {
      const token = auth.access_token
      const player = new (window as any).Spotify.Player({
        name: '352 Legends DJ',
        getOAuthToken: (cb: any) => cb(token),
        volume: 0.8
      })
      player.addListener('ready', ({ device_id }:{device_id:string}) => {
        setDeviceId(device_id)
        setPlayerReady(true)
        transferToDevice(device_id).catch(()=>{})
      })
      player.addListener('not_ready', ({ device_id }:{device_id:string}) => {
        console.log('Device went offline', device_id)
      })
      player.addListener('initialization_error', ({ message }:{message:string}) => console.error(message))
      player.addListener('authentication_error', ({ message }:{message:string}) => console.error(message))
      player.addListener('account_error', ({ message }:{message:string}) => console.error(message))
      player.connect().then(setConnected)
      ;(window as any).__spPlayer = player
      const poll = () => {
        player.getCurrentState().then((state:any)=>{
          if (!state) return
          const t = state.track_window?.current_track
          setTrack(t || null)
          if (!seeking){ setPos(state.position || 0); setDur(state.duration || (t?.duration_ms || 0)) }
        }).finally(()=> setTimeout(poll, 500))
      }
      poll()
      player.addListener('player_state_changed', (s:any) => {
        setTrack(s?.track_window?.current_track || null)
        setPos(s?.position || 0)
      })
    }
    loadSDK()
  }, [auth])

  function connectSpotify(){
    startAuth()
  }

  function playLeague(){
    if (!playlist) return
    let uri = playlist.trim()
    // Accept full playlist URL
    if (uri.includes('open.spotify.com')){
      const m = uri.match(/playlist\/([a-zA-Z0-9]+)/)
      if (m) uri = 'spotify:playlist:' + m[1]
    }
    localStorage.setItem('league_playlist_uri', uri)
    playContext(uri, deviceId).catch(err => alert('Error: ' + err.message))
  }


  // React to mic/aux duck events: smooth Spotify volume
  useEffect(()=>{
    let target = 1.0
    let current = 1.0
    let raf:number
    const player:any = (window as any).__spPlayer
    const smooth = () => {
      current = current + (target - current) * 0.2
      if (player?.setVolume) player.setVolume(Math.max(0.0, Math.min(1.0, current)))
      if (Math.abs(target - current) > 0.01) raf = requestAnimationFrame(smooth)
    }
    const onMic = (e:any) => {
      const duck = parseFloat(localStorage.getItem('duckPercent')||'0.5')
      target = e.detail?.open ? (1 - duck) : 1.0
      cancelAnimationFrame(raf); raf = requestAnimationFrame(smooth)
    }
    const onAux = (e:any) => {
      const duck = parseFloat(localStorage.getItem('duckPercent')||'0.5')
      target = e.detail?.open ? (1 - duck) : 1.0
      cancelAnimationFrame(raf); raf = requestAnimationFrame(smooth)
    }
    window.addEventListener('dj_mic_gate', onMic as any)
    window.addEventListener('dj_aux_duck', onAux as any)
    return () => {
      window.removeEventListener('dj_mic_gate', onMic as any)
      window.removeEventListener('dj_aux_duck', onAux as any)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-xl bg-white/10 grid place-items-center"><Music/></div>
        <div className="flex-1">
          <div className="font-semibold">Now Playing</div>
          <div className="text-xs text-white/70">Single League Playlist via Spotify Premium</div>
        </div>
        {!auth && <button className="btn-white" onClick={connectSpotify}><LinkIcon className="inline mr-2" size={16}/>Connect Spotify</button>}
        {auth && <div className="text-xs text-white/70">Connected</div>}
      </div>

      {track && (
        <div className="flex items-center gap-3 mt-2">
          {track?.album?.images?.[2]?.url && (
            <img src={track.album.images[2].url} alt="art" className="w-12 h-12 rounded-lg object-cover"/>
          )}
          <div className="flex-1 min-w-0">
            <div className="truncate font-medium">{track.name}</div>
            <div className="truncate text-xs opacity-80">{(track.artists||[]).map((a:any)=>a.name).join(', ')}</div>
          </div>
        </div>
      )}

      <div className="mt-2">
        <input className="slider" type="range" min={0} max={Math.max(1,dur)} step={250}
          value={seeking ? undefined : pos}
          onMouseDown={()=>setSeeking(true)}
          onMouseUp onTouchEnd={(e:any)=>{ setSeeking(false); (window as any).__spPlayer?.seek?.(Number(e.target.value)) }}
          onChange={(e:any)=> setPos(Number(e.target.value))}
        />
        <div className="flex justify-between text-[11px] opacity-70">
          <span>{Math.floor(pos/1000)}s</span><span>{Math.floor((dur||0)/1000)}s</span>
        </div>
      </div>

      <div className="grid md:grid-cols-[1fr_auto] gap-3 items-center">
        <input className="input" placeholder="Paste league playlist URL or URI (spotify:playlist:...)" value={playlist} onChange={e=>setPlaylist(e.target.value)} />
        <button className="btn-primary" onClick={playLeague}>Play League Playlist</button>
      </div>

{track && (
        <div className='flex items-center gap-3 mt-3'>
          <img src={track.album?.images?.[2]?.url} className='w-12 h-12 rounded' />
          <div>
            <div className='font-medium'>{track.name}</div>
            <div className='text-xs opacity-70'>{track.artists.map((a:any)=>a.name).join(', ')}</div>
          </div>
        </div>
      )}

      <input type='range' className='slider w-full mt-2' min={0} max={track?.duration_ms||0} value={pos} onChange={e=> (window as any).__spPlayer?.seek?.(parseInt(e.target.value))}/>

      <div className="flex items-center gap-2 mt-3">
        <button className="btn-white" onClick={()=>prevTrack()}><SkipBack size={16}/></button>
        <button className="btn-white" onClick={()=>pause()}><Pause size={16}/></button>
        <button className="btn-white" onClick={()=> (window as any).__spPlayer?.resume?.()}><Play size={16}/></button>
        <button className="btn-white" onClick={()=>nextTrack()}><SkipForward size={16}/></button>
      </div>

      <p className="text-xs text-white/60 mt-3">
        Note: Ducking is applied by lowering Spotify volume while the mic is open. On iOS, tap to start playback due to autoplay policies.
      </p>
    </div>
  )
}
