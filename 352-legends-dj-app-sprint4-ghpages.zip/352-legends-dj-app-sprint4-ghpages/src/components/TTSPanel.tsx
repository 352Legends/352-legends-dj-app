import React, { useEffect, useRef, useState } from 'react'
import { initAudio, attachLocalAudio, setAuxDuck } from '../lib/audio'
import { Volume2 } from 'lucide-react'

export default function TTSPanel(){
  const [line, setLine] = useState('')
  const [queue, setQueue] = useState<string[]>([])
  const [countdown, setCountdown] = useState<number>(0)

  function estimateSeconds(text: string){
    const words = text.trim().split(/\s+/).filter(Boolean).length
    const wpm = 150 * rate // rough scale by rate
    return Math.max(2, Math.round((words / wpm) * 60))
  }

  const [progress, setProgress] = useState(0)
  const [queue, setQueue] = useState<string[]>([])
  const [countdown, setCountdown] = useState<number>(0)

  function estimateSeconds(text: string){
    const words = text.trim().split(/\s+/).filter(Boolean).length
    const wpm = 150 * rate // rough scale by rate
    return Math.max(2, Math.round((words / wpm) * 60))
  }

  const [progress, setProgress] = useState(0)
  const [voice, setVoice] = useState<SpeechSynthesisVoice | null>(null)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [rate, setRate] = useState(1)
  const [pitch, setPitch] = useState(1)

  useEffect(()=>{
    const load = () => setVoices(window.speechSynthesis.getVoices())
    load()
    window.speechSynthesis.onvoiceschanged = load
  }, [])

  


  function enqueue(){
    if (!line.trim()) return
    setQueue(q => [...q, line.trim()])
    setLine('')
  }
  function speak(){

    if (!line.trim()) return
    setQueue([...queue, line.trim()])
    setLine('')
  }

  useEffect(()=>{
    if (queue.length>0 && !window.speechSynthesis.speaking){
      const text = queue[0]
      const u = new SpeechSynthesisUtterance(text)
      if (voice) u.voice = voice
      u.rate = rate; u.pitch = pitch
      u.onstart = () => setAuxDuck(true)
      u.onend = () => { setAuxDuck(false); setQueue(q=>q.slice(1)) }
      window.speechSynthesis.speak(u)
    const est = Math.max(1000, next.split(/\s+/).length*400)
    const start = Date.now()
    timer = setInterval(()=>{ setProgress(Math.min(100, ((Date.now()-start)/est*100))) },200)
    }
  }, [queue, voice, rate, pitch])



    if (!line.trim()) return
    const u = new SpeechSynthesisUtterance(line)
    if (voice) u.voice = voice
    u.rate = rate; u.pitch = pitch
    
    u.onstart = () => setAuxDuck(true)
    u.onend = () => setAuxDuck(false)
    window.speechSynthesis.speak(u)
    const est = Math.max(1000, next.split(/\s+/).length*400)
    const start = Date.now()
    timer = setInterval(()=>{ setProgress(Math.min(100, ((Date.now()-start)/est*100))) },200)

  }


  function runQueue(){
    if(!queue.length) return
    setProgress(0)
    let timer: any;
    if (!queue.length) return
    const next = queue[0]
    const rest = queue.slice(1)
    const u = new SpeechSynthesisUtterance(next)
    if (voice) u.voice = voice
    u.rate = rate; u.pitch = pitch
    u.onstart = () => setAuxDuck(true)
    u.onend = () => { clearInterval(timer); setProgress(100); setAuxDuck(false); setQueue(rest); setTimeout(()=> runQueue(), 100) }
    window.speechSynthesis.speak(u)
    const est = Math.max(1000, next.split(/\s+/).length*400)
    const start = Date.now()
    timer = setInterval(()=>{ setProgress(Math.min(100, ((Date.now()-start)/est*100))) },200)
  }

  return (

    <div className="grid gap-3">
      <textarea className="input min-h-[120px]" placeholder="Sponsor read…"
        value={line} onChange={e=>setLine(e.target.value)} />
      <div className="grid md:grid-cols-3 gap-3">
        <select className="input" value={voice?.name||''} onChange={e=> setVoice(voices.find(v=>v.name===e.target.value) || null)}>
          <option value="">System Default</option>
          {voices.map(v => <option key={v.name} value={v.name}>{v.name}</option>)}
        </select>
        <label className="text-xs opacity-80">Rate
          <input className="slider" type="range" min={0.5} max={2} step={0.1} value={rate} onChange={e=>setRate(parseFloat(e.target.value))} />
        </label>
        <label className="text-xs opacity-80">Pitch
          <input className="slider" type="range" min={0.5} max={2} step={0.1} value={pitch} onChange={e=>setPitch(parseFloat(e.target.value))} />
        </label>
      </div>
      <button className="btn-primary" onClick={speak}>Queue Line</button>
      <div className='text-xs opacity-80'>Queued: {queue.length}</div>
      <p className="text-xs text-white/60">Music will duck while mic is open; TTS plays over music but does not currently auto-duck Spotify volume.</p>
    </div>
  )
}
