import React, { useState } from 'react'
import { Mic, Music, Volume2, QrCode } from 'lucide-react'

export default function Wizard({ onClose }:{ onClose: ()=>void }){
  const [step, setStep] = useState(0)
  const steps = [
    { title: 'Connect Spotify', desc: 'Tap Connect in Now Playing and paste your league playlist.' },
    { title: 'Enable Mic & Ducking', desc: 'Turn the mic ON and test Press-to-Talk. Adjust the Ducking slider.' },
    { title: 'Choose Output', desc: 'Pick your speaker in Settings → Output Device, then play Test Tone.' },
    { title: 'Print QR', desc: 'In Settings, generate a QR for quick access on game day.' },
  ]
  const icons = [<Music key={0}/>, <Mic key={1}/>, <Volume2 key={2}/>, <QrCode key={3}/>]
  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur p-6 grid place-items-center">
      <div className="bg-white/10 ring-1 ring-white/15 rounded-2xl p-6 max-w-xl w-full text-white">
        <div className="text-xl font-semibold mb-2">First-Time Setup</div>
        <div className="text-sm opacity-80 mb-4">Follow these quick steps. You can revisit anytime from Settings.</div>
        <div className="flex items-center gap-3 mb-3">
          <div className="h-10 w-10 rounded-lg bg-white/10 grid place-items-center">{icons[step]}</div>
          <div>
            <div className="font-medium">{steps[step].title}</div>
            <div className="text-xs opacity-80">{steps[step].desc}</div>
          </div>
        </div>
        <div className="flex justify-between mt-4">
          <button className="btn-white" onClick={()=> onClose()}>Skip</button>
          <div className="flex gap-2">
            <button className="btn-white" disabled={step===0} onClick={()=> setStep(s=>Math.max(0, s-1))}>Back</button>
            {step < steps.length-1 ? (
              <button className="btn-primary" onClick={()=> setStep(s=>s+1)}>Next</button>
            ) : (
              <button className="btn-primary" onClick={()=> { localStorage.setItem('wizardDismissed','1'); onClose() }}>Done</button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
