import React, { useEffect, useRef, useState } from 'react'
import { Volume2, Scissors } from 'lucide-react'
import { initAudio, attachLocalAudio } from '../lib/audio'

type Button = { id: string, label: string, src?: string, gain?: number, trim?: {start?: number, end?: number} }

const DEFAULT_BUTTONS: Button[] = [
  { id: 'airhorn', label: 'Air Horn' },
  { id: 'team-intro', label: 'Team Intro' },
  { id: 'anthem', label: 'Anthem Intro' },
  { id: 'touchdown', label: 'Touchdown' },
  { id: 'defense', label: 'Defense' },
  { id: 'timeout', label: 'Timeout' },
  { id: 'buzzer', label: 'Buzzer' },
  { id: 'sponsor1', label: 'Sponsor 1' },
  { id: 'sponsor2', label: 'Sponsor 2' },
]

export default function Soundboard(){
  const [buttons, setButtons] = useState<Button[]>(()=>{
    const raw = localStorage.getItem('sb_buttons')
    return raw ? JSON.parse(raw) : DEFAULT_BUTTONS
  })
  const [mode, setMode] = useState<'cut'|'mix'>(localStorage.getItem('sb_mode') as any || 'cut')
  const [isModal, setIsModal] = useState(false)
  const [editing, setEditing] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploads, setUploads] = useState<any[]>([])
  const audioEls = useRef<Record<string, HTMLAudioElement>>({})

  function stopAll(){
    Object.values(audioEls.current).forEach(el => { el.pause(); el.currentTime = 0 })
  }


  useEffect(()=>{
    // load uploads list from IDB
    const open = indexedDB.open('djapp', 1)
    open.onupgradeneeded = () => {
      const db = open.result
      if (!db.objectStoreNames.contains('uploads')) db.createObjectStore('uploads', { keyPath: 'id' })
    }
    open.onsuccess = () => {
      const db = open.result
      const tx = db.transaction('uploads', 'readonly')
      const store = tx.objectStore('uploads')
      const req = store.getAll()
      req.onsuccess = () => setUploads(req.result || [])
    }
  }, [])


  function saveButtons(list: Button[]){

    setButtons(list)
    localStorage.setItem('sb_buttons', JSON.stringify(list))
    localStorage.setItem('sb_board_name', boardName)
  }

  function pickUploadFor(id: string, uploadId: string){
    const up = uploads.find(u => u.id === uploadId)
    if (!up) return
    const url = URL.createObjectURL(up.blob)
    const next = buttons.map(b => b.id===id ? {...b, src:url} : b)
    saveButtons(next)
  }

  function setGain(id:string, val:number){
    const next = buttons.map(b => b.id===id ? {...b, gain: val} : b)
    saveButtons(next)
  }


  function setTrim(id:string, key:'start'|'end', val:number){

    const next = buttons.map(b => b.id===id ? {...b, trim: {...b.trim, [key]: val}} : b)
    saveButtons(next)
  }

  function play(btn: Button){

    if (mode === 'cut') stopAll()
    let el = audioEls.current[btn.id]
    if (!el){
      el = new Audio()
      el.crossOrigin = 'anonymous'
      // placeholder SFX: generate with WebAudio? Here we expect the user to set src via Uploads panel
      // If no src, play a short beep data URL
      if (!btn.src){
        el.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABYAaWQAAAAAAA=='
      } else {
        el.src = btn.src
      }
      initAudio()
      try { attachLocalAudio(el) } catch {}
      audioEls.current[btn.id] = el
    }
    el.volume = btn.gain ?? 1.0
    el.currentTime = btn.trim?.start || 0
    el.play()
    if (btn.trim?.end){
      const end = btn.trim.end
      const t = setInterval(()=>{
        if (el.currentTime >= end) { el.pause(); clearInterval(t) }
      }, 50)
    }
  }


  function exportBoards(){
    const data = JSON.stringify(buttons)
    const blob = new Blob([data], {type:'application/json'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'soundboard.json'
    a.click()
  }
  function importBoards(e:any){
    const f = e.target.files?.[0]
    if (!f) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const arr = JSON.parse(reader.result as string)
        setButtons(arr)
        localStorage.setItem('sb_buttons', JSON.stringify(arr))
      } catch{ alert('Invalid file') }
    }
    reader.readAsText(f)
  }

  return (

    <div onDragOver={(e)=>e.preventDefault()} onDrop={(e)=>{ e.preventDefault(); const f=e.dataTransfer?.files?.[0]; if(f && f.type==='application/json'){ const r=new FileReader(); r.onload=()=>{ try{ const d=JSON.parse(String(r.result)); if(d?.buttons){ setButtons(d.buttons); setBoardName(d.name||'Imported'); localStorage.setItem('sb_buttons', JSON.stringify(d.buttons)); localStorage.setItem('sb_board_name', d.name||'Imported') } } catch{ alert('Invalid JSON') } }; r.readAsText(f) } }}>
      <div className="flex items-center gap-3 mb-3">
        <div className="text-xs opacity-80">Board:</div>
        <input className="input w-40" value={boardName} onChange={e=>setBoardName(e.target.value)} />
        <button className="btn-white" onClick={saveBoardAs}>Save As</button>
        <select className="input w-40" onChange={e=> e.target.value && loadBoard(e.target.value)}>
          <option value="">Load…</option>
          {availableBoards.map(n => <option key={n} value={n}>{n}</option>)}
        </select>
        <button className="btn-white" onClick={exportBoard}>Export JSON</button>
        <div onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault(); if(e.dataTransfer.files?.length) importBoardFile({target:{files:e.dataTransfer.files}})}} className='border border-dashed border-white/40 p-2 rounded text-xs opacity-80'>Drag & Drop JSON here</div>
        <label className="btn-white cursor-pointer">Import JSON<input type="file" accept="application/json" className="hidden" onChange={importBoardFile}/></label>
        <button className="btn-white" onClick={exportBoards}>Export</button>
        <button className="btn-white" onClick={()=>fileInputRef.current?.click()}>Import</button>
        <input type='file' ref={fileInputRef} style={{display:'none'}} accept='application/json' onChange={importBoards}/>
        <button className="btn-white" onClick={()=>setIsModal(true)}>Open Full Screen</button>
        <div className="text-xs opacity-80">Play Mode</div>
        <button className={`btn-white ${mode==='cut'?'ring-2 ring-brand-red':''}`} onClick={()=>{setMode('cut'); localStorage.setItem('sb_mode','cut')}}>Cut Previous</button>
        <button className={`btn-white ${mode==='mix'?'ring-2 ring-brand-red':''}`} onClick={()=>{setMode('mix'); localStorage.setItem('sb_mode','mix')}}>Mix</button>
        <button className="btn-white" onClick={stopAll}>Stop All</button>
      </div>
      <div className="grid gap-3" style={{gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))'}}>

        {buttons.map(b => (
          <div key={b.id} className="h-24 rounded-2xl bg-white text-blue-800 border border-blue-500 shadow-elev text-lg font-semibold relative overflow-hidden">
            <button className="w-full h-full" onClick={()=>play(b)}>{b.label}</button>
            <button className="absolute top-1 right-1 text-[10px] bg-white/80 px-2 py-1 rounded" onClick={(e)=>{e.stopPropagation(); setEditing(b.id)}}>Edit</button>
          </div>
        ))}
      </div>

      {editing && (
        <div className="mt-3 p-3 rounded-xl bg-white/5">
          <div className="text-sm mb-2">Editing: {buttons.find(x=>x.id===editing)?.label}</div>
          <div className="grid md:grid-cols-4 gap-2">
            <select className="input" onChange={e=>pickUploadFor(editing!, e.target.value)}>
              <option value="">Assign upload…</option>
              {uploads.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <label className="text-xs opacity-80">Gain
              <input className="slider" type="range" min={0} max={1} step={0.05}
                value={buttons.find(x=>x.id===editing)?.gain ?? 1} onChange={e=>setGain(editing!, parseFloat(e.target.value))} />
            </label>
            <label className="text-xs opacity-80">Trim start (s)
              <input className="input" type="number" step="0.1" value={buttons.find(x=>x.id===editing)?.trim?.start ?? 0}
                onChange={e=>setTrim(editing!, 'start', parseFloat(e.target.value||'0'))}/>
            </label>
            <label className="text-xs opacity-80">Trim end (s)
              <input className="input" type="number" step="0.1" value={buttons.find(x=>x.id===editing)?.trim?.end ?? 0}
                onChange={e=>setTrim(editing!, 'end', parseFloat(e.target.value||'0'))}/>
            </label>
          </div>
          <div className="mt-2">
            <button className="btn-white" onClick={()=>setEditing(null)}>Close</button>
          </div>
        </div>
      )}

      {isModal && (
        <div className="fixed inset-0 bg-black/90 z-50 p-4">
          <div className="flex justify-between items-center mb-3">
            <div className="text-lg font-semibold">Soundboard</div>
            <button className="btn-white" onClick={()=>setIsModal(false)}>Close</button>
          </div>
          <div className="grid gap-3" style={{gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))'}}>
            {buttons.map(b => (
              <button key={b.id} className="h-28 rounded-2xl bg-white text-blue-800 border border-blue-500 shadow-elev text-lg font-semibold"
                onClick={()=>play(b)}>{b.label}</button>
            ))}
          </div>
        </div>
      )}

      <p className="text-xs text-white/60 mt-3">Tip: Add audio to buttons via the Uploads panel, then assign to soundboard entries.</p>

    </div>
  )
}

  function saveBoardAs(){
    const name = prompt('Save board as:', boardName) || boardName
    setBoardName(name)
    localStorage.setItem('sb_board_name', name)
    // persist board under name
    localStorage.setItem('sb_buttons:' + name, JSON.stringify(buttons))
    const list = new Set([...(JSON.parse(localStorage.getItem('sb_board_list')||'[]')), name])
    localStorage.setItem('sb_board_list', JSON.stringify([...list]))
    setAvailableBoards([...list])
  }
  function loadBoard(name: string){
    const raw = localStorage.getItem('sb_buttons:' + name)
    if (raw){
      const list = JSON.parse(raw)
      setButtons(list)
      localStorage.setItem('sb_buttons', JSON.stringify(list))
      setBoardName(name)
      localStorage.setItem('sb_board_name', name)
    } else {
      alert('No saved board named ' + name)
    }
  }
  async function exportBoard(){
    // Embed assigned uploads as base64 data URLs for portability (can be large)
    const data:any = { name: boardName, buttons: [] as any[] }
    for (const b of buttons){
      const out:any = { ...b }
      if (b.src && b.src.startsWith('blob:')){
        // Try to fetch blob content and embed
        try {
          const res = await fetch(b.src); const blob = await res.blob()
          const buf = await blob.arrayBuffer()
          const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)))
          out.src = 'data:' + (blob.type || 'audio/wav') + ';base64,' + b64
        } catch {}
      }
      data.buttons.push(out)
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = (boardName || 'soundboard') + '.json'
    a.click()
    URL.revokeObjectURL(url)
  }
  function importBoardFile(e: any){
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result || '{}'))
        if (data?.buttons){
          setButtons(data.buttons)
          setBoardName(data.name || 'Imported')
          localStorage.setItem('sb_buttons', JSON.stringify(data.buttons))
          localStorage.setItem('sb_board_name', data.name || 'Imported')
        }
      } catch (err){ alert('Invalid board file') }
    }
    reader.readAsText(file)
  }
