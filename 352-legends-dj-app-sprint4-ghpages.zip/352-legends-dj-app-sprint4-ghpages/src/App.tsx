import React, { useEffect, useRef, useState } from 'react'
import { Mic, Volume2, Zap, Play, Pause, SkipForward, SkipBack, Music, Upload, Settings as SettingsIcon, Radio, Headphones, QrCode, Waves, Disc3, LayoutGrid } from 'lucide-react'
import NowPlaying from './components/NowPlaying'
import MicrophoneControls from './components/MicrophoneControls'
import Soundboard from './components/Soundboard'
import TTSPanel from './components/TTSPanel'
import OutputDevice from './components/OutputDevice'
import Uploads from './components/Uploads'
import SettingsView from './components/Settings'
import { initAudio } from './lib/audio'
import Wizard from './components/Wizard'
import Wizard from './components/Wizard'

type Tab = 'soundboard' | 'uploads' | 'tts' | 'settings'

export default function App(){
  const [tab, setTab] = useState<Tab>('soundboard')
  const [showWizard, setShowWizard] = useState(()=> !localStorage.getItem('wizardDismissed'))
  const [showWizard, setShowWizard] = useState(()=> !localStorage.getItem('onboard_done'))

  useEffect(() => {
    // Create AudioContext on first user gesture
    const onFirstClick = () => {
      initAudio()
      window.removeEventListener('click', onFirstClick)
      window.removeEventListener('touchstart', onFirstClick)
    }
    window.addEventListener('click', onFirstClick, { once: true })
    window.addEventListener('touchstart', onFirstClick, { once: true })
  }, [])

  return (
    <div className="min-h-screen pb-24">
      <header className="p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-white/10 grid place-items-center"><Disc3 /></div>
        <div className="flex-1">
          <div className="text-lg font-semibold tracking-wide">352 Legends DJ App</div>
          <div className="text-xs text-white/70">Youth Sports DJ + Announcer Booth</div>
        </div>
        <MicrophoneControls />
      </header>

      <main className="p-4 grid gap-4">
        <section className="card">
          <NowPlaying />
        </section>

        <section className="card">
          <div className="flex items-center gap-2 mb-3">
            <LayoutGrid className="opacity-70" /><h2 className="font-semibold">Soundboard & Tools</h2>
          </div>
          <div className="flex gap-2 mb-3">
            <button className={`btn-white ${tab==='soundboard'?'ring-2 ring-brand-red':''}`} onClick={()=>setTab('soundboard')}><Zap className="inline mr-2" size={16}/>Soundboard</button>
            <button className={`btn-white ${tab==='uploads'?'ring-2 ring-brand-red':''}`} onClick={()=>setTab('uploads')}><Upload className="inline mr-2" size={16}/>Uploads</button>
            <button className={`btn-white ${tab==='tts'?'ring-2 ring-brand-red':''}`} onClick={()=>setTab('tts')}><Radio className="inline mr-2" size={16}/>TTS</button>
            <button className={`btn-white ${tab==='settings'?'ring-2 ring-brand-red':''}`} onClick={()=>setTab('settings')}><SettingsIcon className="inline mr-2" size={16}/>Settings</button>
          </div>
          {tab==='soundboard' && <Soundboard />}
          {tab==='uploads' && <Uploads />}
          {tab==='tts' && <TTSPanel />}
          {tab==='settings' && <SettingsView />}
        </section>
      </main>

      {showWizard && <Wizard onClose={()=> setShowWizard(false)} />}

      <div className="sticky-bar flex items-center gap-3">
        <button className="btn-primary"><Play className="inline mr-2" size={16}/>Play</button>
        <button className="btn-white"><Mic className="inline mr-2" size={16}/>PTT</button>
        <button className="btn-white" onClick={() => setTab('soundboard')}><LayoutGrid className="inline mr-2" size={16}/>Soundboard</button>
      </div>
    {showWizard && <Wizard onDone={()=>{ localStorage.setItem('onboard_done','1'); setShowWizard(false)}} />}
    </div>
  )
}
