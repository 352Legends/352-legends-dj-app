// Lightweight Spotify PKCE OAuth + Web Playback SDK helpers.
// NOTE: You must set your CLIENT_ID and REDIRECT_URI in the README/setup.

const CLIENT_ID = import.meta.env.VITE_SPOTIFY_CLIENT_ID || 'YOUR_SPOTIFY_CLIENT_ID'
const REDIRECT_URI = import.meta.env.VITE_SPOTIFY_REDIRECT_URI || window.location.origin + '/'
const TOKEN_ENDPOINT = import.meta.env.VITE_SPOTIFY_TOKEN_ENDPOINT || 'https://accounts.spotify.com/api/token'
const SCOPES = [
  'streaming',
  'user-read-email',
  'user-read-private',
  'user-modify-playback-state',
  'user-read-playback-state',
]

function b64encode(input: ArrayBuffer) {
  // base64-url encode
  const bytes = new Uint8Array(input)
  let str = ''
  for (let i=0; i<bytes.byteLength; i++) str += String.fromCharCode(bytes[i])
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

async function sha256(str: string) {
  const encoder = new TextEncoder()
  const data = encoder.encode(str)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return b64encode(digest)
}

function randStr(len=64){
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~'
  let out = ''
  for (let i=0;i<len;i++) out += chars[Math.floor(Math.random()*chars.length)]
  return out
}

export function startAuth(){
  const codeVerifier = randStr(64)
  localStorage.setItem('sp_code_verifier', codeVerifier)
  const state = randStr(16)
  localStorage.setItem('sp_state', state)
  sha256(codeVerifier).then(codeChallenge => {
    const url = new URL('https://accounts.spotify.com/authorize')
    url.searchParams.set('client_id', CLIENT_ID)
    url.searchParams.set('response_type', 'code')
    url.searchParams.set('redirect_uri', REDIRECT_URI)
    url.searchParams.set('state', state)
    url.searchParams.set('scope', SCOPES.join(' '))
    url.searchParams.set('code_challenge_method', 'S256')
    url.searchParams.set('code_challenge', codeChallenge)
    window.location.href = url.toString()
  })
}

export async function completeAuthIfPresent(){
  const url = new URL(window.location.href)
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state')
  if (!code) return null
  const savedState = localStorage.getItem('sp_state') || ''
  if (state !== savedState) {
    console.warn('State mismatch')
    return null
  }
  const codeVerifier = localStorage.getItem('sp_code_verifier') || ''
  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    grant_type: 'authorization_code',
    code,
    redirect_uri: REDIRECT_URI,
    code_verifier: codeVerifier,
  })
  const res = await fetch(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  })
  const data = await res.json()
  if (data.access_token){
    const at = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in*1000),
    }
    localStorage.setItem('sp_auth', JSON.stringify(at))
    // clean URL
    history.replaceState({}, '', REDIRECT_URI)
    return at
  }
  return null
}

export function getAuth(){
  const raw = localStorage.getItem('sp_auth')
  if (!raw) return null
  try { return JSON.parse(raw) } catch { return null }
}

export async function refreshAuth(){
  const raw = localStorage.getItem('sp_auth')
  if (!raw) return null
  const auth = JSON.parse(raw)
  if (!auth.refresh_token) return null
  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    grant_type: 'refresh_token',
    refresh_token: auth.refresh_token
  })
  const res = await fetch(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  })
  const data = await res.json()
  if (data.access_token){
    const at = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || auth.refresh_token,
      expires_at: Date.now() + (data.expires_in*1000),
    }
    localStorage.setItem('sp_auth', JSON.stringify(at))
    return at
  }
  return null
}

export async function ensureToken(){
  let auth = getAuth()
  if (!auth) return null
  if (Date.now() > auth.expires_at - 60_000){
    auth = await refreshAuth() || auth
  }
  return auth.access_token
}

export async function api(path: string, method='GET', body?: any){
  const token = await ensureToken()
  if (!token) throw new Error('Not authenticated')
  const res = await fetch('https://api.spotify.com/v1' + path, {
    method,
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: body ? JSON.stringify(body) : undefined
  })
  if (res.status === 401) throw new Error('Token expired')
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

export async function transferToDevice(device_id: string){
  return api('/me/player', 'PUT', { device_ids: [device_id], play: false })
}

export async function playContext(uri: string, device_id?: string){
  return api('/me/player/play' + (device_id ? `?device_id=${device_id}`:''), 'PUT', { context_uri: uri })
}

export async function playTracks(uris: string[], device_id?: string){
  return api('/me/player/play' + (device_id ? `?device_id=${device_id}`:''), 'PUT', { uris })
}

export async function pause(device_id?: string){ return api('/me/player/pause' + (device_id ? `?device_id=${device_id}`:''), 'PUT') }
export async function nextTrack(){ return api('/me/player/next','POST') }
export async function prevTrack(){ return api('/me/player/previous','POST') }

// Web Playback SDK loading helper
export function loadSDK(){
  return new Promise<void>((resolve) => {
    if ((window as any).Spotify) return resolve()
    const s = document.createElement('script')
    s.src = 'https://sdk.scdn.co/spotify-player.js'
    s.onload = () => resolve()
    document.body.appendChild(s)
  })
}
