// Minimal IDB wrapper using IndexedDB
export function idb<T=any>(name: string){
  const DB_NAME = 'djapp'
  const STORE = name
  return {
    async withStore(mode: IDBTransactionMode, fn: (s: IDBObjectStore)=>void){
      return new Promise<any>((resolve, reject) => {
        const open = indexedDB.open(DB_NAME, 1)
        open.onupgradeneeded = () => {
          const db = open.result
          if (!db.objectStoreNames.contains('uploads')) db.createObjectStore('uploads', { keyPath: 'id' })
          if (!db.objectStoreNames.contains('soundboards')) db.createObjectStore('soundboards', { keyPath: 'id' })
          if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' })
        }
        open.onsuccess = () => {
          const db = open.result
          const tx = db.transaction(STORE, mode)
          const store = tx.objectStore(STORE)
          fn(store)
          tx.oncomplete = () => resolve(true)
          tx.onerror = () => reject(tx.error)
        }
        open.onerror = () => reject(open.error)
      })
    },
    async getAll(){
      return new Promise<any[]>((resolve, reject) => {
        const open = indexedDB.open(DB_NAME, 1)
        open.onupgradeneeded = () => {
          const db = open.result
          if (!db.objectStoreNames.contains('uploads')) db.createObjectStore('uploads', { keyPath: 'id' })
          if (!db.objectStoreNames.contains('soundboards')) db.createObjectStore('soundboards', { keyPath: 'id' })
          if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' })
        }
        open.onsuccess = () => {
          const db = open.result
          const tx = db.transaction(STORE, 'readonly')
          const store = tx.objectStore(STORE)
          const req = store.getAll()
          req.onsuccess = () => resolve(req.result)
          req.onerror = () => reject(req.error)
        }
        open.onerror = () => reject(open.error)
      })
    },
    async put(obj: any){
      return this.withStore('readwrite', s => s.put(obj))
    },
    async delete(id: string){
      return this.withStore('readwrite', s => s.delete(id))
    }
  }
}
