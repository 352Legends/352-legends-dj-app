// Basic offline shell service worker (no Spotify caching)
const CACHE = '352dj-shell-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (url.origin === location.origin) {
    e.respondWith(
      caches.match(e.request).then(res => res || fetch(e.request))
    );
  }
});


const ART_CACHE = 'art-cache-v1';
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (/\.(png|jpg|jpeg|webp)$/i.test(url.pathname) && /(?:scdn\.|spotifycdn\.)/i.test(url.hostname)) {
    e.respondWith((async () => {
      const cache = await caches.open(ART_CACHE);
      const cached = await cache.match(e.request);
      const fetchAndUpdate = fetch(e.request).then(res => { cache.put(e.request, res.clone()); return res });
      return cached || fetchAndUpdate;
    })());
  }
});
