export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') {
      return new Response('', { headers: corsHeaders() })
    }
    const url = new URL(req.url)
    if (url.pathname !== '/token') return new Response('Not Found', { status: 404, headers: corsHeaders() })
    const body = await req.text()
    // Forward to Spotify accounts token endpoint
    const res = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    })
    const data = await res.text()
    return new Response(data, { status: res.status, headers: { ...corsHeaders(), 'Content-Type': 'application/json' } })
  }
}
function corsHeaders(){
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization'
  }
}
