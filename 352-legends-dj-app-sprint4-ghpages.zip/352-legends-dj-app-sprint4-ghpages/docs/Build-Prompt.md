# 2) Single Build Prompt — Paste into your code generator

**Title:** Build “352 Legends DJ App” — a browser-based youth sports DJ + announcer tool

**Context:** Production-quality React app with premium UX, zero-server MVP, Spotify Web Playback SDK integration. Brand is red/white/blue; **all text white**; **white buttons = blue text + blue border**.

**Tech:** Vite + React + Tailwind (+ lucide-react), Web Audio API, Web Speech API (TTS), IndexedDB (idb), PWA.  
**Goal:** Stable, beautiful, mobile-first app anyone can operate with zero budget/skill.

**Functional Requirements**  
- **Access & PWA**: Instant load; installable; offline shell for Uploads/Soundboard. Settings includes QR generator.  
- **Spotify (Premium)**: OAuth (PKCE). Create Spotify Connect device (Web Playback SDK). Under “Now Playing”: input to paste league playlist URI/URL; Save; Play League Playlist. Show transport (Play/Pause/Prev/Next/Seek), art/title/artist/elapsed/duration. If non-Premium/invalid token: clear message, no crash.  
- **Announcer Mic**: Header mic switch (on/off). Large Press-to-Talk (pulsing). **Ducking**: reduce music volume by slider % while mic gate open. **Stadium FX**: Reverb, Echo/Delay, Crowd ambience. FX toggle + optional monitor.  
- **Soundboard (default lower)**: Big grid of stingers (Air Horn, Team Intro, Anthem intro, etc.). Per-button gain & trim; **mode** = Cut vs Mix. Full-screen modal on mobile with Close button. Save/Load boards; Export/Import JSON (+ audio) via IndexedDB.  
- **Uploads/Custom Playlists**: Upload MP3/WAV to IndexedDB. Create simple playlists from uploads.  
- **Output Device**: If `setSinkId` supported → “Choose Speaker”; else show OS steps. **Test Tone** button.  
- **Settings**: Autoplay helper; PWA install; latency tips; Reset App (clear IndexedDB/localStorage).

**Non-functional & UX**  
- All text white; **white buttons bg-white text-blue-800 border-blue-500**.  
- Brand: navy gradient background, red accents for primaries.  
- Sticky bottom bar (mobile): Play, Mic PTT, Soundboard.  
- WCAG 2.2 AA; 44×44 touch targets; keyboard focus states.  
- Smooth 50–100ms ramps for ducking; zero pops.

**Audio Graph**  
- Local audio `<audio>` → MediaElementSource → MusicGain.  
- Mic (getUserMedia) → FX chain (reverb, delay, crowd bed) → MicGain.  
- Mix → MasterGain → MediaStreamDestination → `<audio srcObject>`; `setSinkId` here.  
- Spotify volume duck via SDK while mic open.

**State (IndexedDB)**  
- settings `{ duckPercent, outputDeviceId, fxEnabled, fx:{reverb,echo,crowd} }`  
- leaguePlaylist `{ uri }`  
- uploads `{ id, name, blobMeta, duration }`  
- soundboards `{ id, name, buttons:[…] }`

**Testing**  
- Unit: ducking math; soundboard modes; IDB CRUD.  
- E2E (Playwright): login → device connect → paste playlist → play → PTT ducks → open soundboard modal → play stinger → close.

**Deliverables**  
- Production-ready repo, README with step-by-step setup (screenshots later).  
- PWA manifest, service worker, icons.  
- `docs/` with Game Day guide, latency tips, QR printable.  
- Optional CI lint/test.

**Implementation Notes**  
- Respect autoplay: activate AudioContext on first tap.  
- Safari/iOS caveats visible.  
- Never upload mic audio.  
- Acceptance (Chrome): Spotify plays playlist; PTT ducks; FX audible; stingers work; mobile full-screen grid.  
- Acceptance (iOS): user gesture starts audio; mic works where permitted; fallback text if unavailable.
