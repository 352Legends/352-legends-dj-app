import React from 'react'
import { QRCodeCanvas } from 'qrcode.react'

export default function Qr({ value }: { value: string }){
  return (
    <div className="p-4 bg-white text-black rounded-xl inline-block">
      <QRCodeCanvas value={value} size={180} includeMargin />
      <div className="text-[10px] opacity-60 mt-1 w-[180px] text-center break-all">{value}</div>
    </div>
  )
}
