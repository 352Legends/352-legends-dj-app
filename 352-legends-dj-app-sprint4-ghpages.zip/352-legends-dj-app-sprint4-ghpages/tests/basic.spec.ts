import { test, expect } from '@playwright/test';

test('app loads and soundboard is visible', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('352 Legends DJ App')).toBeVisible();
  await expect(page.getByText('Soundboard & Tools')).toBeVisible();
});

test('open fullscreen soundboard modal', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Open Full Screen' }).click();
  await expect(page.getByText('Soundboard')).toBeVisible();
  await page.getByRole('button', { name: 'Close' }).click();
});
