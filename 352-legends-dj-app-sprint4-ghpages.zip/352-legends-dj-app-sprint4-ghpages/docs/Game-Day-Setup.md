# Game Day Setup — 352 Legends DJ App

1) **Open the App**
- Use the QR code in **Settings** to load the app on your device.
- For iOS, add to Home Screen for a cleaner full-screen experience.

2) **Connect Audio**
- Prefer **wired** (3.5mm) when possible to reduce latency.
- If Bluetooth, keep the device close to the speaker and disable enhancements (spatial audio, EQ).

3) **Choose Output**
- Go to **Settings → Output Device**.
- If your browser supports it, pick your speaker and tap **Test Tone**. Otherwise, use your OS sound menu.

4) **Microphone**
- Tap **Mic: OFF** to enable and grant permission.
- Use **Press-to-Talk** (PTT) for announcements. Music ducks while you speak.
- Adjust the **Ducking** slider until the music sits comfortably under your voice.

5) **Spotify Playlist**
- Tap **Connect Spotify** (Premium required).
- Paste the **league playlist** URI/URL and press **Play League Playlist**.

6) **Soundboard**
- Default view under **Soundboard & Tools**.
- Tap a tile (Air Horn, Touchdown, etc.).
- Use **Open Full Screen** on mobile for bigger buttons.

7) **Sponsor Reads (TTS)**
- Type your line in **TTS** and tap **Speak**. Music auto-ducks during speech.

8) **Uploads**
- Add MP3/WAV for local playback and assign to soundboard tiles (works offline).

## Quick Troubleshooting
- **No sound?** Check OS volume & speaker, then use **Test Tone**. Some platforms need a first tap to start audio.
- **Spotify won’t play?** Confirm Premium, reconnect, and ensure the “352 Legends DJ” device is selected.
- **Mic echo?** Avoid enabling sidetone on speakers; keep mic and speaker apart.
