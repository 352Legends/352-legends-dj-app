import React, { useEffect, useRef, useState } from 'react'
import { Mic, Waves } from 'lucide-react'
import { initAudio, openMic, setDuckAmount, setMicGate, setFX } from '../lib/audio'

export default function MicrophoneControls(){
  const [enabled, setEnabled] = useState(false)
  const [ptt, setPtt] = useState(false)
  const [duck, setDuck] = useState(0.5)
  const [monitor, setMonitor] = useState(true)
  const [fxOpen, setFxOpen] = useState(false)
  const [echoTime, setEchoTime] = useState(0.25)
  const [echoFeedback, setEchoFeedback] = useState(0.2)
  const [crowd, setCrowd] = useState(0.0)
  const [uploads, setUploads] = useState<any[]>([])
  const [crowdFile, setCrowdFile] = useState<any>(null)
  const [crowd, setCrowd] = useState(0)
  const [sidetone, setSidetone] = useState(false)

  useEffect(()=>{ setDuckAmount(duck) }, [])
  function toggleEnable(){
    if (!enabled){
      initAudio()
      openMic().then(()=>{
        setEnabled(true)
        setMicGate(false)
      }).catch(()=> alert('Mic permission needed.'))
    } else {
      setEnabled(false)
      setMicGate(false)
    }
  }

  function onPTTDown(){
    if (!enabled){ return }
    setPtt(true); setMicGate(true)
  }
  function onPTTUp(){
    setPtt(false); setMicGate(false)
  }

  function onDuckChange(v:number){
    setDuck(v); setSetting('duckPercent', v); setDuckAmount(v)
  }


  useEffect(()=>{ setFX({crowd}) }, [crowd])

  return (

    <div className="card flex items-center gap-3">
      <button className={`btn-white ${enabled?'ring-2 ring-brand-red':''}`} onClick={toggleEnable}>
        <Mic className="inline mr-2" size={16}/>{enabled?'Mic: ON':'Mic: OFF'}
      </button>
      <div className="hidden md:flex items-center gap-2">
        <Waves size={16} className="opacity-70"/><span className="text-xs opacity-80">Ducking</span>
        <input className="slider" type="range" min={0} max={0.95} step={0.05} value={duck} onChange={e=>onDuckChange(parseFloat(e.target.value))} />
      </div>

      <div className="hidden md:flex items-center gap-2">
        <span className="text-xs opacity-80">Crowd</span>
        <input className="slider" type="range" min={0} max={1} step={0.05} value={crowd} onChange={e=>setCrowd(parseFloat(e.target.value))} />
      </div>
      <div className="hidden md:flex items-center gap-2">
        <label className="text-xs opacity-80"><input type="checkbox" checked={sidetone} onChange={e=>setSidetone(e.target.checked)} /> Sidetone Monitor (experimental)</label>
      </div>

      <button
        className={`btn-primary ${ptt?'scale-95 ring-4 ring-red-400/40':''}`}
        onMouseDown={onPTTDown}
        onMouseUp={onPTTUp}
        onTouchStart={(e)=>{e.preventDefault(); onPTTDown()}}
        onTouchEnd={(e)=>{e.preventDefault(); onPTTUp()}}
        >
        <Mic className="inline mr-2" size={16}/>Press-to-Talk
      </button>
    
      <label className="ml-2 text-xs flex items-center gap-2">
        <input type="checkbox" checked={monitor} onChange={e=>{ setMonitor(e.target.checked); setMonitorEnabled(e.target.checked); setSetting('monitor', e.target.checked) }} />
        Monitor (speaker)
      </label>
      <button className="btn-white ml-auto" onClick={()=>setFxOpen(v=>!v)}><Cog size={16} className="inline mr-2"/>FX</button>
    </div>
    {fxOpen && (
      <div className="mt-2 p-3 rounded-xl bg-white/5">
        <div className="grid md:grid-cols-3 gap-3">
          <label className="text-xs opacity-80">Echo Time (s)
            <input className="slider" type="range" min={0} max={1} step={0.01}
              value={echoTime} onChange={e=>{ const v=parseFloat(e.target.value); setEchoTime(v); setFXControls({ echoTime: v, echoFeedback, crowd }); setSetting('fx.echoTime', v) }} />
          </label>
          <label className="text-xs opacity-80">Echo Feedback
            <input className="slider" type="range" min={0} max={0.95} step={0.01}
              value={echoFeedback} onChange={e=>{ const v=parseFloat(e.target.value); setEchoFeedback(v); setFXControls({ echoTime, echoFeedback: v, crowd }); setSetting('fx.echoFeedback', v) }} />
          </label>
          <label className="text-xs opacity-80">Crowd Ambience
            <input className="slider" type="range" min={0} max={0.6} step={0.01}
              value={crowd} onChange={e=>{ const v=parseFloat(e.target.value); setCrowd(v); setFXControls({ echoTime, echoFeedback, crowd: v }); setSetting('fx.crowd', v) }} />
          </label>
        </div>
        <input type='file' accept='audio/*' onChange={e=>setCrowdFile(e.target.files?.[0]||null)} className='text-xs'/>
        <p className="text-[11px] opacity-70 mt-1">Crowd ambience can use an uploaded loop; default is noise.Crowd ambience is a subtle loop mixed under your mic. Use sparingly to avoid mush.</p>
      </div>
    )}
  </div>
  )
}
