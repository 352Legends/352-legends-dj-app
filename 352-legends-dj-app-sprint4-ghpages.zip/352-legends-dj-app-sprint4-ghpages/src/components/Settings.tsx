import React, { useEffect, useMemo, useState } from 'react'
import OutputDevice from './OutputDevice'
import Qr from './qr'

export default function SettingsView(){
  const [url, setUrl] = useState(window.location.href)
  const [a2hs, setA2hs] = useState<any>(null)
  useEffect(()=>{
    const handler = (e:any)=>{ e.preventDefault(); setA2hs(e) }
    window.addEventListener('beforeinstallprompt', handler)
    return ()=>window.removeEventListener('beforeinstallprompt', handler)
  },[])

  function reset(){
    if (confirm('Reset app? This clears local settings/uploads.')){
      indexedDB.deleteDatabase('djapp')
      localStorage.clear()
      location.reload()
    }
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h3 className="font-semibold mb-2">QR Code</h3>
        <Qr value={url} />
        <input className="input w-full mt-2" value={url} onChange={e=>setUrl(e.target.value)} />
      </div>
      <div>
        <h3 className="font-semibold mb-2">Output Device</h3>
        <OutputDevice />
        <h3 className="font-semibold mt-6 mb-2">Utilities</h3>
        <div className="flex gap-2">
          <button className="btn-white" onClick={()=> a2hs ? (a2hs.prompt(), setA2hs(null)) : (window as any).alert('Use your browser menu → Add to Home Screen')}>PWA Install</button>
          <button className="btn-white" onClick={reset}>Reset App</button>
        </div>
        <p className="text-xs opacity-80 mt-3">Latency tips: Prefer wired where possible. If Bluetooth, disable spatial audio and enhancements. Keep device near the speaker.</p>
      </div>
    </div>
  )
}
