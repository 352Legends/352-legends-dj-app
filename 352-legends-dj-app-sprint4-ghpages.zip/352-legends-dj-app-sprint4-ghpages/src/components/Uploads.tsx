import React, { useEffect, useState } from 'react'
import { idb } from '../lib/idb'

type UploadRec = { id: string, name: string, blob: Blob, duration?: number }

export default function Uploads(){
  const [items, setItems] = useState<UploadRec[]>([])

  async function refresh(){
    const store = idb<UploadRec>('uploads')
    const all = await store.getAll()
    setItems(all)
  }
  useEffect(()=>{ refresh() }, [])

  async function onFile(e: React.ChangeEvent<HTMLInputElement>){
    const files = e.target.files
    if (!files) return
    const store = idb<UploadRec>('uploads')
    for (const f of Array.from(files)){
      const rec: UploadRec = { id: crypto.randomUUID(), name: f.name, blob: f }
      await store.put(rec)
    }
    refresh()
  }

  async function del(id: string){
    await idb('uploads').delete(id)
    refresh()
  }

  function urlFor(rec: UploadRec){
    return URL.createObjectURL(rec.blob)
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <input type="file" accept="audio/*" multiple onChange={onFile} className="text-sm"/>
      </div>
      <div className="grid gap-2">
        {items.map(it => (
          <div key={it.id} className="flex items-center gap-3 bg-white/5 p-2 rounded-xl">
            <div className="flex-1">
              <div className="font-medium">{it.name}</div>
              <div className="text-xs opacity-70">{(it.blob.size/1024/1024).toFixed(2)} MB</div>
            </div>
            <audio controls src={urlFor(it)} className="max-w-[240px]"></audio>
            <button className="btn-white" onClick={()=>del(it.id)}>Delete</button>
          </div>
        ))}
      </div>
      <p className="text-xs text-white/60 mt-3">Uploads are stored locally (IndexedDB) for offline use.</p>
    </div>
  )
}
