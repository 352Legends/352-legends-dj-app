import React, { useEffect, useState } from 'react'
import { getOutputDevices, setOutputDevice, playTestTone } from '../lib/audio'

export default function OutputDevice(){
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([])
  const [supported, setSupported] = useState(false)

  useEffect(()=>{
    ;(async ()=>{
      const list = await getOutputDevices()
      // @ts-ignore
      setSupported(!!HTMLMediaElement.prototype.setSinkId)
      setDevices(list as any)
    })()
  }, [])

  async function choose(id: string){
    try {
      await setOutputDevice(id)
      alert('Output set. Play test tone to confirm.')
    } catch (e:any){
      alert(e.message)
    }
  }

  return (
    <div className="grid gap-2">
      {supported ? (
        <select className="input" onChange={e=>choose(e.target.value)}>
          <option value="">Select Output Device…</option>
          {devices.map(d => <option key={d.deviceId} value={d.deviceId}>{d.label || 'Speaker'}</option>)}
        </select>
      ) : (
        <p className="text-sm opacity-80">Output device selection not supported on this browser. Use the OS sound output menu.</p>
      )}
      <button className="btn-white" onClick={()=>playTestTone()}>Test Tone</button>
    </div>
  )
}
