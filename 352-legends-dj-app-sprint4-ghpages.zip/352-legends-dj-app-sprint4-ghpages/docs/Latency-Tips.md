# Latency Tips (Voice + Music)

- **Wired beats Bluetooth** for live announcing.
- If Bluetooth is required:
  - Disable spatial audio / surround modes.
  - Keep the device within a few feet of the speaker.
  - Avoid sharing the Bluetooth link with multiple devices.
- **Start the audio context with a tap** on iOS/Safari (autoplay policy).
- **Use PTT** instead of a continuous mic when possible to reduce feedback risk.
