// Persistent settings using IndexedDB 'settings' store with localStorage fallback.

type Val = any

function openDB(): Promise<IDBDatabase>{
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('djapp', 1)
    open.onupgradeneeded = () => {
      const db = open.result
      if (!db.objectStoreNames.contains('uploads')) db.createObjectStore('uploads', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('soundboards')) db.createObjectStore('soundboards', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' })
    }
    open.onsuccess = () => resolve(open.result)
    open.onerror = () => reject(open.error)
  })
}

export async function setSetting(key: string, value: Val){
  try {
    const db = await openDB()
    const tx = db.transaction('settings', 'readwrite')
    tx.objectStore('settings').put({ key, value })
    await new Promise((res, rej)=>{ tx.oncomplete = ()=>res(true); tx.onerror = ()=>rej(tx.error) })
  } catch {
    localStorage.setItem('settings:' + key, JSON.stringify(value))
  }
}

export async function getSetting<T=any>(key: string, fallback?: T): Promise<T>{
  try {
    const db = await openDB()
    const tx = db.transaction('settings', 'readonly')
    const req = tx.objectStore('settings').get(key)
    const val = await new Promise<any>((res, rej)=>{
      req.onsuccess = ()=> res(req.result?.value)
      req.onerror = ()=> rej(req.error)
    })
    if (val === undefined) return fallback as T
    return val as T
  } catch {
    const raw = localStorage.getItem('settings:' + key)
    if (!raw) return fallback as T
    try { return JSON.parse(raw) as T } catch { return fallback as T }
  }
}

export async function getAllSettings(): Promise<Record<string,Val>>{
  const out: Record<string,Val> = {}
  try {
    const db = await openDB()
    const tx = db.transaction('settings', 'readonly')
    const store = tx.objectStore('settings')
    const req = store.getAll()
    const rows = await new Promise<any[]>((res, rej)=>{
      req.onsuccess = ()=> res(req.result||[])
      req.onerror = ()=> rej(req.error)
    })
    rows.forEach(r => { out[r.key] = r.value })
    return out
  } catch {
    Object.keys(localStorage).forEach(k => {
      if (k.startsWith('settings:')){
        try { out[k.slice(9)] = JSON.parse(localStorage.getItem(k) || 'null') } catch {}
      }
    })
    return out
  }
}
