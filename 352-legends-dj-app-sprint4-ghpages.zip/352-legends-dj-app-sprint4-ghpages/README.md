# 352 Legends DJ App

A browser-based DJ + announcer booth for youth sports. Spotify (Premium) for music, live mic with ducking + FX, soundboard, TTS, uploads, and PWA. Brand: navy/red/white. All text white; white buttons have blue text + blue border.

---

## Quick Start

```bash
pnpm i # or npm i / yarn
pnpm dev
```

Then open http://localhost:5173

### Environment
Create `.env` at project root:

```
VITE_SPOTIFY_CLIENT_ID=YOUR_SPOTIFY_CLIENT_ID
VITE_SPOTIFY_REDIRECT_URI=http://localhost:5173
```

In Spotify Dashboard:
- Add your app, copy **Client ID**.
- Set **Redirect URI** to the URL above (and your production URL).

### Build
```bash
pnpm build && pnpm preview
```

### Deploy
- Netlify/Cloudflare Pages: deploy the repo; ensure HTTPS. No server required.

---

## Features

- **Spotify Premium**: Connect and play a single league playlist; transport controls.
- **Mic + PTT**: Press-to-talk; smooth **ducking** during mic; **FX** (reverb, delay, crowd).
- **Soundboard**: Big buttons; cut or mix; assign audio from **Uploads**.
- **TTS**: Web Speech for sponsor reads.
- **Uploads**: MP3/WAV stored in **IndexedDB** for offline use.
- **Output Device**: Choose speaker (where `setSinkId` supported) + **Test Tone**.
- **PWA**: Offline shell. QR generator for quick access.

---

## Known Limitations

- Spotify audio cannot be routed through Web Audio; ducking is applied via SDK volume while the mic/FX path uses Web Audio. Output routing selection does **not** control Spotify output—use OS sound selector for Spotify if needed.
- iOS requires a user gesture to start audio. Some mic routings are restricted by the platform.

---

## Files of Note

- `src/lib/audio.ts` — Audio graph (mic FX, ducking, output routing via MediaStreamDestination).
- `src/lib/spotify.ts` — PKCE OAuth + Web API helpers; Web Playback SDK loader.
- `src/components/*` — UI: Now Playing, Mic Controls, Soundboard, TTS, Uploads, Settings.
- `public/sw.js` + `public/manifest.webmanifest` — PWA shell.
- `src/components/qr.tsx` — Placeholder QR (replace with `qrcode.react` for production).

---

## Docs

- See `/docs/Feature-Requirements.md` and `/docs/Build-Prompt.md`.
- Add your **Game Day setup one-pager** and **Latency tips** in `/docs/` as needed.

---

## License

MIT


---

**Sprint 1 Enhancements:** Real QR codes, Spotify auto-duck on mic/TTS, fullscreen soundboard, per-button edit (assign uploads/gain/trim), A2HS prompt capture, docs for Game Day + Latency.


**Sprint 2 Enhancements:** Soundboard Export/Import JSON, crowd ambience slider, sidetone monitor toggle, queued sponsor reads.

**Sprint 2 Enhancements:** Named soundboard boards with Save/Load + Export/Import JSON (embeds audio), FX controls (echo, feedback, crowd ambience), monitor toggle, and a sponsor-read queue with auto-duck.

**Sprint 3 Enhancements:** Spotify timeline/artwork + seek, drag/drop JSON import, crowd ambience from uploaded file, Playwright e2e skeleton, and onboarding wizard for first-time users.

**Sprint 3 Enhancements:** Now Playing shows artwork/title/artist + live timeline/seek; Soundboard supports drag‑and‑drop JSON import; Crowd ambience can use an **Upload** as the bed; First‑Time Setup Wizard; Playwright e2e skeleton with `npm run test:e2e`.

**Sprint 4 Enhancements:**
- **Persistent settings** via IndexedDB (`duckPercent`, monitor, FX values, etc.).
- **TTS Sponsor Queue UI** with estimated durations, live countdown, reorder & clear.
- **Mobile-friendly scrub**: tap/hold/drag on the timeline to seek.
- **Album art caching** in Service Worker (stale-while-revalidate for Spotify CDN images).
- **Cloudflare Worker (optional)**: `/workers/spotify-proxy.js` to proxy the token exchange. Use env:
  - `VITE_SPOTIFY_TOKEN_ENDPOINT=https://<your-worker>.workers.dev/token`

To enable the worker proxy: deploy the worker, then set `VITE_SPOTIFY_TOKEN_ENDPOINT` in `.env`.


## Deploying to GitHub Pages

1. **Create a repo** on GitHub (e.g., `352-legends-dj-app`). Push this project to the `main` branch.
2. In **Settings → Pages**, set **Build and deployment** to **GitHub Actions** (no need to select a branch once Actions runs).
3. In **Settings → Secrets and variables → Actions → Variables**, add:
   - `VITE_SPOTIFY_CLIENT_ID` — your Spotify client ID (front-end embed; will be visible in bundle).
   - `VITE_SPOTIFY_REDIRECT_URI` — e.g. `https://<user>.github.io/352-legends-dj-app/`
   - (Optional) `VITE_SPOTIFY_TOKEN_ENDPOINT` — your Cloudflare Worker endpoint, if used.
   - `VITE_BASE_PATH` — set to `/352-legends-dj-app/` (or `/` if using a `user.github.io` root repo).
4. Commit & push to `main`. The included workflow `.github/workflows/deploy.yml` will build and publish to Pages.
5. On first run, GitHub may prompt you to **Enable GitHub Pages** for this repo. Approve when asked.

> **Note:** For subpath deployments (`/<repo>/`), the app uses `VITE_BASE_PATH` to ensure correct asset URLs.
