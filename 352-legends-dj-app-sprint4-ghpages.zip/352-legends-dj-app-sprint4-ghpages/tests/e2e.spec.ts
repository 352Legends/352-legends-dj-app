import { test, expect } from '@playwright/test'

test('basic flow', async ({ page }) => {
  await page.goto('/')
  await expect(page.locator('text=352 Legends DJ App')).toBeVisible()
  // Simulate mic controls UI
  await page.locator('button:has-text("Mic")').first().click()
  await page.locator('button:has-text("Press-to-Talk")').first().click({ delay:200 })
  // Soundboard open
  await page.locator('button:has-text("Soundboard")').first().click()
})
