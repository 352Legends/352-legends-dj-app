# 352 Legends DJ App — Feature Requirements

## 1) Feature Requirements (Finalized)
[Copied from your brief and normalized for delivery.]

1.1 **Product summary**  
A browser-based DJ + announcer booth for youth sports. Runs on any modern laptop/tablet/phone with a Bluetooth (or wired) speaker. Music via Spotify Premium (league playlist), live mic to PA with ducking + stadium FX, soundboard for stingers/sponsor reads, TTS (no-cost Web Speech), uploads for local audio, and PWA install for zero-budget operations. Branded red/white/blue as “352 Legends DJ App.”

1.2 **Personas**  
- **Game Day Operator (non-technical):** needs tap-big buttons, no setup hassle.  
- **League Admin (semi-technical):** sets playlist, prints QR, pushes sponsor reads.  
- **Coach/Volunteer:** occasional operator on mobile; must be foolproof.  
- **Spectator:** none (no audience-facing UI).

1.3 **Platforms / Constraints**  
- **Browsers:** Chrome/Edge (desktop + Android) optimal; Safari/iOS supported with limitations (autoplay, mic routing).  
- **Audio Output:** Bluetooth speaker or wired. Device selection via `setSinkId()` where supported; fallback to OS-level selection.  
- **Zero server (MVP):** local-first IndexedDB for uploads/config; optional Netlify/Cloudflare for hosting.  
- **Spotify Premium** required for music via Web Playback SDK.

2. **Functional Requirements**
2.1 **Access & Onboarding**
- QR Access: simple URL with QR code printable from Settings.
- PWA Install: “Add to Home Screen” prompt; offline shell for uploads/soundboard.
- Permissions Wizard: guides user to grant mic permission and choose audio output.

2.2 **Spotify Integration (Single League Playlist)**
- Connect Spotify (Premium): OAuth flow (PKCE); app registers as Spotify Connect device.
- Device Transfer: on connect, transfer playback to the app device (no auto-play).
- Inline Playlist under Now Playing: paste league playlist URI/URL, save locally, **Play League Playlist** button.
- Transport: Play, Pause, Next, Previous, Seek, Timeline, Track title/artist/art.
- Volume & Loudness: master gain (local audio) + Spotify volume API.  
- **Behavior:** while PTT Mic is active, duck music by the current slider % (via Spotify volume when streaming; via WebAudio for local audio).
- **Edge cases**: token expired → re-auth prompt; no Premium → friendly message; iOS autoplay → require a user tap.

2.3 **Announcer Mic**
- Persistent Mic Switch (header card): toggle on/off for continuous reads.
- **PTT Button:** big, pulsing hold-to-talk (press → Mic ON; release → OFF).
- **Ducking:** attenuate music by slider % while mic gate is open.
- **Stadium FX (Mic only):** Reverb (size/time mix), Echo/Delay (time/feedback), Crowd Ambience bed (looped SFX mixed under mic; independent gain), FX Bypass toggle.
- **Monitor Toggle:** sidetone monitor (visual-only where echo-cancel can’t be guaranteed).

2.4 **Soundboard (Default in lower section)**
- Default tab = Soundboard.
- Grid buttons: Air Horn, Team Intro, National Anthem intro, Touchdown/Goal stingers, Timeout, “Defense”, Buzzer, Sponsor 1/2, Coin Toss, Halftime, etc.
- One-Shot Playback with overlap rules: **Cut previous** or **Mix**.
- Per-button gain and optional trim (start/end).
- Full-screen Modal on Mobile: large grid; Close button.
- Save/Load Boards: JSON + audio assets (IndexedDB). Export/Import JSON for sharing.

2.5 **Text-to-Speech (Sponsor Reads)**
- Type a line → Speak (Web Speech).
- Voice selection + rate/pitch; queue multiple lines.
- Auto-duck music during TTS (roadmap: direct Spotify volume duck on speechstart/end).

2.6 **Uploads & Custom Playlists (Local)**
- Upload MP3/WAV to IndexedDB.
- Build custom playlists from local tracks; reorder/rename/delete.
- Use custom lists in Soundboard or sequential play.

2.7 **Output Device**
- Show current Output Device label; if `setSinkId` supported → Choose Speaker dialog; else show OS-level instructions.
- **Test Tone** button to confirm routing.

2.8 **Settings**
- **QR Generator** for app URL.
- **Autoplay Policy Helper** (“Tap to Start” banner where needed).
- **Latency Tips** (wired vs Bluetooth, echo-cancel notes).
- **PWA Install** button; **Reset App** (clear IndexedDB/localStorage).

3. **Non-Functional Requirements**
3.1 **UX & Visual**
- All text white; brand palette navy + red accents + white; **white buttons have blue text + blue border**.
- Touch-first: 44×44 px minimum; visible focus states; WCAG 2.2 AA contrast.
- **Sticky mobile control bar:** Play, PTT Mic, Soundboard.

3.2 **Performance**
- Initial load <150KB JS (excl. SDKs); lazy-load heavy pieces.
- Audio graph activation <50ms on tap.
- No jank toggling mic/soundboard.

3.3 **Reliability & Offline**
- Offline: uploads, soundboard, TTS continue offline; Spotify disables gracefully.
- Recoverable errors with plain-language guidance.

3.4 **Security & Privacy**
- No server token storage; tokens in localStorage only.
- No external analytics by default.
- Mic audio never leaves the device.

3.5 **Compatibility**
- Chrome/Edge latest (full feature).
- Safari (macOS/iOS): mic/autoplay caveats communicated.
- Firefox: partial (no setSinkId); warn & guide.

4. **Architecture & Implementation**
4.1 **Tech Stack**
- **Vite + React + Tailwind** (+ lucide-react icons).  
- **Spotify Web Playback SDK**.  
- **Web Audio API** (mic FX, ducking, mixing), **Web Speech API** (TTS).  
- **IndexedDB** (idb) for uploads/boards/settings.  
- **PWA**: service worker + manifest (offline shell).

4.2 **Audio Graph (simplified)**
```
[Local Audio <audio>] -> [MediaElementSource] -> [MusicGain] -\
[Mic getUserMedia] -> [FX: Reverb->Delay->Crowd] -> [MicGain] ---+--> [MasterGain] -> [MediaStreamDestination] -> <output element (setSinkId)>
                                                                   ^
[Spotify] (duck via SDK volume) -----------------------------------/
```

Ducking: while mic gate is open, set `MusicGain.gain = (1 - duckPercent)` and reduce Spotify SDK volume accordingly (50–100ms smoothing).

4.3 **Data Model (IndexedDB)**
- settings: `{ duckPercent, outputDeviceId, fxEnabled, fx:{reverb,echo,crowd} }`
- leaguePlaylist: `{ uri }`
- uploads: `{ id, name, blobMeta, duration }`
- soundboards: `{ id, name, buttons: [{id,label,src,type:'upload'|'tts'|'sfx', gain, trim:{start,end}}] }`

4.4 **Permissions**
- `getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } })`
- Output selection via `HTMLMediaElement.setSinkId(deviceId)` when available.

5. **Testing & Acceptance Criteria**
5.1 **Unit/Integration (high level)**
- Audio Graph: ducking sets music gain correctly on mic gate; FX toggles map to node bypass.
- Uploads: add MP3/WAV, persist across reload, delete.
- Soundboard: one-shot play, cut/mix rules; full-screen modal opens/closes.
- Spotify: device connects, playlist plays, controls work; fallback messages for non-Premium.
- PWA: offline shell loads; soundboard usable offline.

5.2 **Manual QA Checklist**
- Bluetooth chosen in Settings (or OS) & test tone audible.
- Mic PTT ducks music exactly to slider %.
- TTS speaks; no clipping.
- Full-screen soundboard visible on mobile; large tap targets.
- Single “League Playlist” saved and playable via Now Playing card.

5.3 **Edge Cases**
- Token expired → “Reconnect Spotify” CTA.
- iOS: requires user tap to start audio → inline helper.
- No mic permission → announce with TTS only (no crash).
