let audioCtx: AudioContext | null = null
let masterGain: GainNode
let musicGain: GainNode
let micGain: GainNode
let delayNode: DelayNode
let feedbackGain: GainNode
let convolver: ConvolverNode
let crowdGain: GainNode
let destinationNode: MediaStreamDestination
let monitorEnabled = true
let crowdSource: AudioBufferSourceNode | null = null
let outputEl: HTMLAudioElement | null = null

let baseMusicVolume = 1.0
let duckPercent = 0.5
let micOpen = false

function createImpulseResponse(ctx: AudioContext, seconds = 1.4, decay = 2.0) {
  const rate = ctx.sampleRate
  const length = rate * seconds
  const impulse = ctx.createBuffer(2, length, rate)
  for (let c = 0; c < 2; c++){
    const ch = impulse.getChannelData(c)
    for (let i = 0; i < length; i++){
      ch[i] = (Math.random()*2 - 1) * Math.pow(1 - i/length, decay)
    }
  }
  return impulse
}

export function initAudio() {
  if (audioCtx) return
  audioCtx = new AudioContext()
  masterGain = audioCtx.createGain()
  musicGain = audioCtx.createGain()
  micGain = audioCtx.createGain()
  crowdGain = audioCtx.createGain()
  micGain.gain.value = 0 // closed by default
  crowdGain.gain.value = 0.0

  // FX chain: Convolver -> Delay loop
  convolver = audioCtx.createConvolver()
  convolver.buffer = createImpulseResponse(audioCtx, 1.2, 2.5)
  delayNode = audioCtx.createDelay(5.0)
  feedbackGain = audioCtx.createGain()
  feedbackGain.gain.value = 0.2
  delayNode.delayTime.value = 0.25 // 250ms

  // Connect mic -> convolver -> delay -> micGain
  micGain.connect(masterGain)
  const micFxIn = audioCtx.createGain()
  micFxIn.connect(convolver)
  convolver.connect(delayNode)
  delayNode.connect(feedbackGain)
  feedbackGain.connect(delayNode)
  delayNode.connect(micGain)

  // Crowd -> master
  crowdGain.connect(masterGain)

  // Music -> master
  musicGain.connect(masterGain)

  // Route to MediaStreamDestination so we can choose output device with setSinkId
  destinationNode = audioCtx.createMediaStreamDestination()
  masterGain.connect(destinationNode)

  // attach to hidden audio element
  outputEl = document.createElement('audio')
  outputEl.autoplay = true
  outputEl.srcObject = destinationNode.stream
  outputEl.volume = 1.0
  document.body.appendChild(outputEl)
}

export function getAudioContext() { return audioCtx }

export function createElementSource(el: HTMLMediaElement) {
  if (!audioCtx) throw new Error('Audio not initialized')
  return audioCtx.createMediaElementSource(el)
}

export async function openMic() {
  if (!audioCtx) throw new Error('Audio not initialized')
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
  })
  const source = audioCtx.createMediaStreamSource(stream)
  // send to FX path (which ultimately goes to micGain)
  source.connect(micGain)
  return true
}


function broadcastDuck(open:boolean){
  try { window.dispatchEvent(new CustomEvent('dj_mic_gate', { detail: { open } })) } catch {}
}
export function setMicGate(open: boolean){

  if (!audioCtx) return
  micOpen = open
  broadcastDuck(open)
  const now = audioCtx.currentTime
  const targetMusic = micOpen ? (1 - duckPercent) : 1.0
  musicGain.gain.setTargetAtTime(targetMusic, now, 0.05)
  micGain.gain.setTargetAtTime(micOpen ? (monitorEnabled ? 1.0 : 0.0) : 0.0, now, 0.02)
}

export function setDuckAmount(percent: number){
  duckPercent = Math.min(1, Math.max(0, percent))
  if (!audioCtx) return
  const now = audioCtx.currentTime
  const targetMusic = micOpen ? (1 - duckPercent) : 1.0
  musicGain.gain.setTargetAtTime(targetMusic, now, 0.05)
}

export function attachLocalAudio(el: HTMLMediaElement){
  if (!audioCtx) throw new Error('Audio not initialized')
  const src = audioCtx.createMediaElementSource(el)
  src.connect(musicGain)
}

export function playTestTone(){
  if (!audioCtx) throw new Error('Audio not initialized')
  const osc = audioCtx.createOscillator()
  const g = audioCtx.createGain()
  g.gain.value = 0.05
  osc.frequency.value = 880
  osc.connect(g).connect(masterGain)
  osc.start()
  setTimeout(()=>osc.stop(), 500)
}

export async function setOutputDevice(deviceId: string){
  if (!outputEl || !('setSinkId' in outputEl)) {
    throw new Error('setSinkId not supported; use OS sound output selector.')
  }
  // @ts-ignore
  await outputEl.setSinkId(deviceId)
}

export function setFX({ reverb = 0.5, echoTime = 0.25, echoFeedback = 0.2, crowd = 0.0 }){
  if (!audioCtx) return
  delayNode.delayTime.value = echoTime
  feedbackGain.gain.value = echoFeedback
  // Simple reverb amount by changing wet/dry via convolver + direct path.
  // Here we keep it subtle by using the delay line mostly.
  micGain.gain.value = micOpen ? 1.0 : 0.0
  crowdGain.gain.value = crowd
}

export function getOutputDevices(){
  if (!('mediaDevices' in navigator) || !navigator.mediaDevices.enumerateDevices) return Promise.resolve([])
  return navigator.mediaDevices.enumerateDevices().then(list => list.filter(d => d.kind === 'audiooutput'))
}

export function setAuxDuck(open:boolean){
  // Allow TTS or other events to temporarily duck music without opening mic
  if (!audioCtx) return
  const now = audioCtx.currentTime
  const targetMusic = open ? (1 - duckPercent) : 1.0
  musicGain.gain.setTargetAtTime(targetMusic, now, 0.05)
  try { window.dispatchEvent(new CustomEvent('dj_aux_duck', { detail: { open } })) } catch {}
}

function createNoiseBuffer(ctx: AudioContext, seconds=2){
  const rate = ctx.sampleRate
  const length = rate * seconds
  const buf = ctx.createBuffer(1, length, rate)
  const ch = buf.getChannelData(0)
  for (let i=0; i<length; i++){ ch[i] = (Math.random()*2 - 1) * 0.15 }
  return buf
}
function ensureCrowd(){
  if (!audioCtx) return
  if (crowdSource) return
  crowdSource = audioCtx.createBufferSource()
  crowdSource.buffer = createNoiseBuffer(audioCtx, 2)
  crowdSource.loop = true
  crowdSource.connect(crowdGain)
  crowdSource.start()
}
function stopCrowd(){
  if (crowdSource){
    try { crowdSource.stop() } catch {}
    try { crowdSource.disconnect() } catch {}
    crowdSource = null
  }
}

export function setMonitorEnabled(on:boolean){
  monitorEnabled = on
  if (!audioCtx) return
  const now = audioCtx.currentTime
  const target = (micOpen && monitorEnabled) ? 1.0 : 0.0
  micGain.gain.setTargetAtTime(target, now, 0.02)
}
export function setFXControls({ reverb = 0.5, echoTime = 0.25, echoFeedback = 0.2, crowd = 0.0 }){
  if (!audioCtx) return
  delayNode.delayTime.value = echoTime
  feedbackGain.gain.value = echoFeedback
  crowdGain.gain.value = crowd
  if (crowd > 0.001) ensureCrowd(); else stopCrowd()
}

export async function setCrowdSrcFromUrl(url:string){
  if (!audioCtx) return
  try {
    const res = await fetch(url)
    const buf = await res.arrayBuffer()
    const audioBuf = await audioCtx.decodeAudioData(buf)
    stopCrowd()
    crowdSource = audioCtx.createBufferSource()
    crowdSource.buffer = audioBuf
    crowdSource.loop = true
    crowdSource.connect(crowdGain)
    crowdSource.start()
  } catch (e){ console.warn('Failed to set crowd src', e) }
}
